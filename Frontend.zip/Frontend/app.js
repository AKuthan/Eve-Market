const { createApp, defineAsyncComponent } = Vue;

const MarketComponent = defineAsyncComponent(() =>
    fetch("market.html")
        .then(response => response.text())
        .then(template => ({
            template,
            data() {
                return {
                    regionId: "",
                    itemId: "",
                    stationNames: {},
                    marketData: []
                };
            },
            methods: {
                async fetchMarketData() {
                    if (!this.regionId || !this.itemId) {
                        alert("Lütfen geçerli bir Bölge ID ve Ürün ID girin.");
                        return;
                    }

                    const url = `http://localhost:3000/market/${this.regionId}/${this.itemId}`;
                    try {
                        const response = await fetch(url);
                        const data = await response.json();
                        for (const entry of data) {
                            if (!this.stationNames[entry.location_id]) {
                                await this.fetchStationName(entry.location_id);
                            }
                        }
                        this.marketData = data.length
                        ? data.map(entry => ({
                            price: entry.price,
                            volume_remain: entry.volume_remain,
                            location_name: this.stationNames[entry.location_id] || `Bilinmeyen İstasyon (${entry.location_id})`
                        }))
                        : [{ price: "Veri yok", volume_remain: "-", location_name: "-" }];
                    } catch (error) {
                        console.error("Veri alınırken hata oluştu:", error);
                        this.marketData = [{ price: "API Hatası", volume_remain: "-", location_id: "-" }];
                    }
                },
                async fetchStationName(stationId) {
                    try {
                        const response = await fetch(`http://localhost:3000/station/${stationId}`);
                        const data = await response.json();
                        this.stationNames[stationId] = data.name;
                    } catch (error) {
                        console.error(`İstasyon ID ${stationId} alınamadı.`);
                        this.stationNames[stationId] = `Bilinmeyen İstasyon (${stationId})`;
                    }
                }
            }
            

            
        }))
);

createApp({
    components: { MarketComponent }
}).mount("#app");